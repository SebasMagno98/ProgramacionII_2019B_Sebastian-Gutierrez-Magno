#pragma once
//Librerias generales
#include <string>
#include <iostream>


//Librerias de Clases Animales
#include "Animales.h"
#include "Mamifero.h"
#include "oviparos.h"
#include "Aguila.h"
#include "Caballito_Mar.h"
#include "Cocodrilo.h"
#include "Delfin.h"
#include "Hiena.h"
#include "leon.h"
#include "Iguana.h"
#include "tigre.h"
#include "Tiburon.h"
#include "Lobo.h"
#include "Loro.h"
#include "puma.h"
using namespace std;